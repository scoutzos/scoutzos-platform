export const calculateCashFlow = (income: number, expenses: number) => {
    return income - expenses;
};
