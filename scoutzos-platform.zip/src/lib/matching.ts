export const matchDealToBuyBox = (deal: any, buyBox: any) => {
    // Placeholder matching logic
    return 0;
};
