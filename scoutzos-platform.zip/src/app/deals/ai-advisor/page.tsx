import { ComingSoon } from '@/components/ComingSoon';

export default function AIAdvisorPage() {
  return <ComingSoon title="AI Advisor" />;
}
