import { ComingSoon } from '@/components/ComingSoon';

export default function SettingsPage() {
  return <ComingSoon title="Settings" />;
}
